package cn.sharesdk.socialization.sample.apshare;

import cn.sharesdk.alipay.share.AlipayHandlerActivity;

public class ShareEntryActivity extends AlipayHandlerActivity{

}
